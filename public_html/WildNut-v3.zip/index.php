<?php include('include/header.php') ?>

		

	 <!--Body Content Started-->
		<main class="main-body">
			<section style="background-image: url('images/banner.jpg');" class="default-section banner-section">
				<div class="container">
          <div class="row h-100 align-items-center">
            <div class="col-lg-9">
                <h1 class="h2">Wild Nut brings you deliciously wholesome products born out of a healthy lifestyle and a passion for GOOD FOOD.</h1>
                <p>From the earth's bounty and through a selection of its best and finest ingredients we pack-up rich, delectable & incredibly nutritious foods to be savoured and to fuel you up at any time of day.</p>
            </div>
          </div>
				</div>
			</section>

      <section class="default-section our-story-section section-top-border pt-0 pb-4" id="our-story">
				<div class="container">
          <div class="logo-w text-center mb-3"><img alt="" src="images/logo-w.png" width="86" height="103"></div>
          <div class="row">
            <div class="col-lg-10 m-auto text-center">
              <h2 class="title-section mb-4 pb-2">Our Story</h1>
              <p>Our Story is quite simple actually. We are proud Syrian girls who got the privilege of traveling all around the world and trying all kinds of foods. Coming back to Syria made us realize that nutritious and wholesome foods can be grown in our rich soiled lands. </p>
              <p>With this, we decided to create a local brand made from the love our land to share with the world. Our mission is to create an inspiring sustainable brand that is responsible and environment friendly. This is something we live and work by every day.</p>
            </div>
          </div>
				</div>
			</section>

       
      <section style="background-image: url('images/bg-2.jpg');" class="default-section profile-section py-4">
				<div class="container">
          <div class="row">
            <div class="col-md-4">
               <div class="profile-card">
                <div class="profile-photo">
                    <img alt="" src="images/profile-3.png" width="224" height="239">
                </div>
                <h3>Gida Hussami</h3>
                <p>Food lover, Yogi, traveller, ocean child and a hazelnut maniac</p>
               </div>
            </div>

            <div class="col-md-4">
              <div class="profile-card">
               <div class="profile-photo">
                   <img alt="" src="images/profile-1.png" width="224" height="239">
               </div>
               <h3>Aya Ajami</h3>
               <p>Wild child at heart, sports enthusiast and a crunch addict</p>
              </div>
           </div>

           <div class="col-md-4">
            <div class="profile-card">
             <div class="profile-photo">
                 <img alt="" src="images/profile-2.png" width="224" height="239">
             </div>
             <h3>Nadia Nahhas</h3>
             <p>Adventure seeker and a peanut butter admirer</p>
            </div>
         </div>
          </div>
				</div>
			</section>


      <section class="default-section our-products-section section-top-border pt-0 pb-5" id="our-products">
				<div class="container">
          <div class="logo-w text-center mb-3"><img alt="" src="images/logo-w.png" width="86" height="103"></div>
          <h2 class="title-section mb-4 pb-2 text-center">Our Products</h1>
          <div class="row justify-content-center">
            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-1.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Smooth Peanut Butter </h4>
                  <p>All natural, preservatives free, smooth grounded peanuts</p>
              </div>
            </div>
            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-2.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Crunchy Peanut Butter</h4>
                  <p>All natural, preservatives free, crunchy grounded peanuts</p>
              </div>
            </div>
            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-3.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Smooth Almond Butter</h4>
                  <p>All natural, preservatives free, smooth grounded almonds</p>
              </div>
            </div>


            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-4.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Crunchy Almond Butter</h4>
                  <p>All natural, preservatives free, crunchy grounded almonds</p>
              </div>
            </div>
            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-5.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Cashew Butter</h4>
                  <p>All natural, preservatives free, smooth grounded cashews</p>
              </div>
            </div>
            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-6.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Cacao-Hazelnut butter</h4>
                  <p>All natural, preservatives free, grounded almonds and hazelnuts</p>
              </div>
            </div>

            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-7.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Cacao-Cashew Butter</h4>
                  <p>All natural, preservatives free, grounded cachews with organic cacao</p>
              </div>
            </div>
            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-8.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Granola Classic</h4>
                  <p>All natural, honey sweetened oats and nuts mix </p>
              </div>
            </div>
            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-9.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Granola Peanut Butter </h4>
                  <p>All natural, honey sweetened oats and peanut mix</p>
              </div>
            </div>
            <div class="col-sm-6 col-md-4">
              <div class="products-card">
                  <div style="background-image: url('images/products/img-10.jpg');" class="img-div">
                    <img alt="" src="images/product-spot.png" width="317" height="317">
                  </div>
                  <h4>Wild Zaatar</h4>
                  <p>All natural, herb blend for dips, seasoning and much more</p>
              </div>
            </div>
          </div>
				</div>
			</section>

      <section class="default-section our-approach-section section-top-border pt-0 pb-0" id="our-approach">
				<div class="container">
          <div class="logo-w text-center mb-3"><img alt="" src="images/logo-w.png" width="86" height="103"></div>
          <div class="row mb-5">
            <div class="col-lg-10 m-auto text-center">
              <h2 class="title-section mb-4 pb-2">Our Approach</h1>
              <p>Wild Nut kitchen is located in the heart of Damascus. We push to hire underprivileged women, not only because we believe women and mothers have a delicate taste and familiarity in the kitchen but also for these women to stand up on their feet, be independent and lead a better life. We teach them skills which they master over time to become essential members of our handmade goods.
                </p>
              <p>We are strong advocates of “you are what you eat”. This is why our product range from gluten free, sugar free, dairy free to keto friendly. We want to support all types of bodies to get the nutrition they need with clean and natural ingredients.</p>
            </div>
          </div>
				</div>
        <div class="single-img-div">
          <img alt="" src="images/out-approach-img.jpg" width="1366" height="604" class="w-100">
        </div>
			</section>

      <section class="default-section gallery-section section-top-border pt-0 pb-5" id="gallery">
				<div class="container-fluid p-0">
          <div class="logo-w text-center mb-3"><img alt="" src="images/logo-w.png" width="86" height="103"></div>
          <h2 class="title-section mb-5 pb-2 text-center">Gallery</h1>
          <!-- Swiper -->
        <div class="swiper mySwiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-1.jpg">
            </div>
            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-2.jpg">
            </div> 
            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-3.jpg">
            </div>
            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-4.jpg">
            </div>
            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-5.jpg">
            </div>
            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-6.jpg">
            </div>
            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-7.jpg">
            </div>
            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-8.jpg">
            </div>

            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-9.jpg">
            </div>

            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-10.jpg">
            </div>

            <div class="swiper-slide">
              <img alt="" src="images/gallery/p-11.jpg">
            </div>

          </div> 
          <div class="swiper-button-next"></div>
         <div class="swiper-button-prev"></div>
        </div>
				</div> 
			</section>

      <section class="default-section contact-us-section section-top-border pt-0 pb-4" id="order-yours">
				<div class="container">
          <div class="logo-w text-center mb-3"><img alt="" src="images/logo-w.png" width="86" height="103"></div>
          <div class="row mb-5">
            <div class="col-lg-10 m-auto text-center">
              <h2 class="title-section mb-4 pb-2">Contact Us</h1>
              <p>For your orders and any other inquiries.</p>
              <p>We would love to hear from you on any suggestions you have, so stay in touch!</p>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-md-6">
                <div class="contact-card me-lg-3">
                  <h2 class="text-center">Syria</h2>
                  <div class="d-flex align-items-center mb-3">
                    <div class="icon">
                      <img alt="" src="images/contact-icon-1.png">
                    </div>
                    <div class="text">
                      <a href="tel:+963 11 223 2100">+963 11 223 2100</a>
                    </div>
                  </div>
                  <div class="d-flex align-items-center  mb-3">
                    <div class="icon">
                      <img alt="" src="images/contact-icon-2.png">
                    </div>
                    <div class="text">
                      <a href="https://web.whatsapp.com/" target="_blank">+963 968 400 885</a>
                    </div>
                  </div>
                  <div class="d-flex align-items-center">
                    <div class="icon">
                      <img alt="" src="images/contact-icon-3.png">
                    </div>
                    <div class="text">
                      <a href="https://www.instagram.com/wildwildnut/" target="_blank">@wildwildnut</a>
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-md-6">
              <div class="contact-card ms-lg-3">
                <h2 class="text-center">UAE</h2>
                <div class="d-flex align-items-center mb-3">
                  <div class="icon">
                    <img alt="" src="images/contact-icon-1.png">
                  </div>
                  <div class="text">
                    <a href="tel:+971 58 599 7180">+971 58 599 7180</a>
                  </div>
                </div>
                <div class="d-flex align-items-center  mb-3">
                  <div class="icon">
                    <img alt="" src="images/contact-icon-2.png">
                  </div>
                  <div class="text">
                    <a href="https://web.whatsapp.com/" target="_blank">+971 58 599 7180</a>
                  </div>
                </div>
                <div class="d-flex align-items-center">
                  <div class="icon">
                    <img alt="" src="images/contact-icon-4.png">
                  </div>
                  <div class="text">
                    <a href="mailto:info@wildnut.co">info@wildnut.co</a>
                  </div>
                </div>
              </div>
          </div>
          </div>
				</div>
			</section>

		</main>
	<!--Body Content StarEndted-->
		
		
		
	<?php include('include/footer.php') ?>