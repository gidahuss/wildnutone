	 <!--Main Footer Started-->
     <footer class="main-footer">
			<div class="container">
                <div class="row  align-items-center">
                <div class="col-lg-7">
                    <div class="d-lg-flex align-items-center">
                        <div class="footer-logo"> 
                        <p>a product of..</p>
                        <a href="index.php"><img alt="" src="images/Wild-foods-logo-white.png" width="94"></a>
                        </div>
                        <ul>
                        <li>
                            <a href="privacy-policy.php">Privacy policy</a>
                        </li>
                        <li>
                            <a href="terms-and-condition.php">Terms & conditions</a>
                        </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-5 d-sm-flex justify-content-center justify-content-lg-end mt-2 mt-lg-0">
                    <div class="text-center">© Wild Nut L.L.C </div>
                    <div class="footer-social-icon">
                    <a href="https://www.facebook.com/wildwildnut/"  target="_blank"><img alt="" src="images/social/icon-1.png" width="32" height="32"></a>
                    <a href="https://www.instagram.com/wildwildnut/" target="_blank"><img alt="" src="images/social/icon-2.png" width="32" height="32"></a>
                    <a href="https://vm.tiktok.com/ZSe2McK8n/"  target="_blank"><img alt="" src="images/social/icon-3.png" width="32" height="32"></a>
                    <a href="https://www.youtube.com/channel/UCUfkeRXSqFsisgsf8BEdGgg"  target="_blank"><img alt="" src="images/social/icon-4.png" width="32" height="32"></a></div>
                </div>
                </div>
			</div>
		</footer>
		<!--Main Footer Started-->
		
	</div> 
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/swiper-bundle.min.js"></script> 
	<script src="js/scripts.js"></script> 
  </body>
</html>